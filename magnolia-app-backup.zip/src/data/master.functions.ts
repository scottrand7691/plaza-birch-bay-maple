import { createServerFn } from "@tanstack/react-start";

export type MasterBook = {
  saved: string;
  lots: unknown[];
};

const FILE = "data/magnolia-master.json";

export const readMaster = createServerFn({ method: "GET" }).handler(async (): Promise<MasterBook | null> => {
  const { readFile } = await import("node:fs/promises");
  const { join } = await import("node:path");
  try {
    const raw = await readFile(join(process.cwd(), FILE), "utf8");
    const parsed = JSON.parse(raw) as MasterBook;
    if (!parsed || !Array.isArray(parsed.lots)) return null;
    return parsed;
  } catch {
    return null;
  }
});

export const writeMaster = createServerFn({ method: "POST" })
  .validator((data: MasterBook) => {
    if (!data || !Array.isArray(data.lots)) throw new Error("Master file needs a lot list");
    return {
      saved: typeof data.saved === "string" ? data.saved : new Date().toISOString(),
      lots: data.lots,
    };
  })
  .handler(async ({ data }) => {
    const { mkdir, readFile, writeFile } = await import("node:fs/promises");
    const { dirname, join } = await import("node:path");
    const file = join(process.cwd(), FILE);
    await mkdir(dirname(file), { recursive: true });
    const lotsBody = JSON.stringify(data.lots);
    try {
      const current = JSON.parse(await readFile(file, "utf8")) as MasterBook;
      if (Array.isArray(current.lots) && JSON.stringify(current.lots) === lotsBody) {
        return { ok: true as const, count: data.lots.length };
      }
    } catch {
      /* the file is created below */
    }
    await writeFile(file, `${JSON.stringify({ saved: data.saved, lots: data.lots })}\n`);
    return { ok: true as const, count: data.lots.length };
  });
